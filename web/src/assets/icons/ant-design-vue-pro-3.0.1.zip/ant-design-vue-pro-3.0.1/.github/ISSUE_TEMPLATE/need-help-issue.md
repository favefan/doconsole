---
name: Need help issue
about: Question for use（问题求助）
title: ''
labels: question
assignees: ''

---

**Question （问题描述）**
How to use component `s-table` paging

**Describe the solution you'd like （你期待的是什么？）**
A clear and concise description of what you want to happen.

**Additional context（附加信息）**
Add any other context or screenshots about the feature request here.
