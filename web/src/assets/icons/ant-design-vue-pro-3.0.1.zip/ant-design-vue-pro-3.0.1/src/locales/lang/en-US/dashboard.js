import analysis from './dashboard/analysis'

export default {
    ...analysis
  }
